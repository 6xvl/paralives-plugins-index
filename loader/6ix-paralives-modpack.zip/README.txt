﻿6ix Paralives Modpack
=====================

This zip bundles BepInEx 5 (forked) + Plugin Hub + Stats Overlay +
Cross-Volume Write Fix.

INSTALL:
  1. Find your Paralives folder (Steam -> right-click Paralives -> Manage -> Browse local files)
  2. Extract this zip directly into that folder. You should see winhttp.dll next to Paralives.exe.
  3. Launch the game. The 'Plugin Hub' tab will appear inside the Mods menu.
  4. Browse Plugin Hub to install any other mods you want (FPS Limiter, Workshop Unlock, etc.)

INCLUDED FIXES:
  - Cross-Volume Write Fix: works around a Paralives 0.1.2 regression that breaks
    Workshop mod loading on multi-drive Steam setups (Steam library on a
    different drive than %TEMP%). Auto-installed for everyone by default.

UNINSTALL:
  Delete winhttp.dll, doorstop_config.ini, .doorstop_version, and the BepInEx folder.
  Game returns to vanilla.

For updates and more mods: https://github.com/6xvl/paralives-plugins-index
