﻿6ix Paralives Modpack
=====================

Mods for Paralives, installed from inside the game.
One zip for Windows, Steam Deck / Linux, and Mac. Pick yours below.

Each one is the same idea: unzip into your game folder, start the game,
and open  Mods -> Plugin Hub.


============================  WINDOWS  ============================

  1. Open your Paralives folder:
     Steam -> right-click Paralives -> Manage -> Browse local files
     (you'll see Paralives.exe in it).
  2. Unzip this download into that folder.
     winhttp.dll should end up right next to Paralives.exe.
  3. Start the game. On the main menu click Mods -> Plugin Hub.

  Done!


======================  STEAM DECK / LINUX  ======================

  Same as Windows, plus one line to paste.

  1. Open your Paralives folder and unzip this download into it.
  2. Steam -> right-click Paralives -> Properties -> Launch Options,
     and paste this into the box:

        WINEDLLOVERRIDES="winhttp=n,b" %command%

  3. Start the game. Open Mods -> Plugin Hub.

  (That line tells Steam to use the mod loader. To undo, empty the box.)


=============================  MAC  ==============================

  Everything is already in the zip. You just paste two short commands.

  1. Open your Paralives folder:
     Steam -> right-click Paralives -> Manage -> Browse local files
     (you'll see Paralives.app in it).
  2. Unzip this download into that folder, so run_bepinex.sh lands
     next to Paralives.app.
  3. Open Terminal in that folder, then copy-paste these two lines
     (press Enter after each):

        chmod +x run_bepinex.sh
        xattr -dr com.apple.quarantine .

     (these just let Mac run the loader - it's blocked by default
      because you downloaded it.)
  4. Tell Steam to use it: right-click Paralives -> Properties ->
     Launch Options, and paste the full path to run_bepinex.sh, a space,
     then %command%. To get the exact path, type  pwd  in the Terminal
     from step 3 and add /run_bepinex.sh on the end. Example:

        "/Users/YOU/Library/Application Support/Steam/steamapps/common/Paralives/run_bepinex.sh" %command%

  5. Start the game. Open Mods -> Plugin Hub.

  (Mac support is new - if it doesn't show up, ask in the Discord below.)


===========================  UPDATING  ===========================

  Plugin Hub updates itself and your mods every time you launch -
  nothing to do. To update this bundle, download the zip again and
  overwrite.


==========================  UNINSTALL  ===========================

  Windows / Linux: delete winhttp.dll, doorstop_config.ini,
                   .doorstop_version, and the BepInEx folder.
  Mac:             delete run_bepinex.sh, libdoorstop.dylib, the BepInEx
                   folder, and empty the Steam Launch Options.
  The game goes back to normal.


More mods and the full guide:
  https://github.com/6xvl/paralives-plugins-index

Need help? Discord: https://discord.gg/XMXRPTDJv5
  (join, find the mods channel, open the "[Plugin Hub] Help" thread.)
